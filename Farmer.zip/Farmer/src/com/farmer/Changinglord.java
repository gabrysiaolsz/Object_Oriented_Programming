package com.farmer;

public class Changinglord extends Farmer //farmer "plodozmian"
{
    int interval; //ilosc warzyw zebranych podczas zbioru
    int jump; //podzial ogrodu
    int start_point; //indeks poczatkowy podczas zbioru

    Changinglord(int size)
    {
        jump = 3;
        interval = 1/jump * size;
        start_point = 0;
    }

    @Override
    protected void turn(Garden garden, int turn_number)
    {
        if(turn_number % jump == 0 && turn_number != 0)
        {
            if(start_point == jump - 1) //przy ostatnim zbiorze farmer zbiera do konca
            {
                for(int i = start_point * interval; i < garden.getNumberOfSlots(); i++)
                    gather(garden, i);

                start_point = 0;
            }
            else
            {
                for (int i = 0; i < interval; i++)
                    gather(garden, i + interval * start_point);

                start_point++;
            }
        }
    }

}
