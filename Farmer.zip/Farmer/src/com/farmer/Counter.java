package com.farmer;

public class Counter
{
    String id;
    int count;

    Counter(String id)
    {
        this.id = id;
        count = 0;
    }

    public String getCounter()
    {
        String tmp = new String(id +": " + count);
        return tmp;
    }

    public void add()
    {
        count++;
    }
}
