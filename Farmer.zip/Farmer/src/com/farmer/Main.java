package com.farmer;

public class Main
{
    public static void main(String[] args)
    {
        int garden_size = 120;
        int days = 120;

        Farmer[] farmer = new Farmer[]{new Landlord(garden_size), new Lazylord(), new Changinglord(garden_size)}; //tablica pozwala na latwe poszerzanie ilosci taktyk

        System.out.println("Symulacja ogrodu wielkosci " + garden_size + " przez " + days + " dni\n\n");


        for(int i = 0; i < farmer.length; i++)
        {
            Garden garden = new Garden(garden_size);

            System.out.println("Symulacja klasy " + farmer[i].getClass().getName().substring(11) + ": ");

            farmer[i].simulate(garden, days);
        }
    }
}
