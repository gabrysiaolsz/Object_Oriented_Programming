package com.farmer;

public abstract class Vegetable
{
    float seed_price;
    int age;

    public float getSeed_price()
    {
        return seed_price;
    }

    public void older()
    {
        age++;
    }

    public abstract float price_check();

}
