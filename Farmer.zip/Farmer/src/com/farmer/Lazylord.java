package com.farmer;

public class Lazylord extends Farmer //farmer zbierajacy co 10 dni
{

    @Override
    protected void turn(Garden garden, int turn_number)
    {
        if(turn_number % 10 == 0 && turn_number != 0)
        {
            for(int i = 0; i < garden.getNumberOfSlots(); i++)
                gather(garden, i);
        }

    }
}
