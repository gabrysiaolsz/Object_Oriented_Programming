package com.farmer;

public class Carrot extends Vegetable
{
    Carrot()
    {
        seed_price = 7.5f;
        age = 0;
    }

    @Override
    public float price_check() //szybko wzrasta szybko maleje
    {
        if(age > 12)
            return 0;

         else
            return ((float)(age * age * age) * (age - 24) * (age - 12) / 2000);

    }
}
