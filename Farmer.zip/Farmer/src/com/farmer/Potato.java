package com.farmer;

public class Potato extends Vegetable
{
    Potato()
    {
        seed_price = 5.0f;
        age = 0;
    }

    @Override
    public float price_check() //ziemniak rosnie i maleje skokowo
    {
        if(age < 5)
            return 0.0f;

        else if(age < 20)
            return 12.0f;

        else if(age < 30)
            return 7.0f;

        else
            return 2.0f;
    }
}
