package com.farmer;
import java.util.Arrays;

public class Landlord extends Farmer //farmer zbierajacy przy malejacych cenach
{

    float[] price;

    Landlord(int size)
    {
        price = new float[size];
        Arrays.fill(price, -1.0f);
    }

    @Override
    protected void turn(Garden garden, int turn_number)
    {
        for(int i = 0; i < garden.getNumberOfSlots(); i++)
        {
            float recent_price = garden.evaluate_price(i);

            if(recent_price != -1)
            {
                if (price[i] > recent_price)
                {
                    gather(garden, i);
                    price[i] = -1;
                }
                else
                    price[i] = recent_price;
            }
        }

    }
}
