package com.farmer;
import java.util.Random;

public abstract class Farmer
{
    float income;
    float costs;
    Counter[] counters; //liczniki dla kazdego warzywa pozwalaja na optymalne trzymanie informacji o zebranych warzywach

    public void simulate(Garden garden, int days)
    {
        counters = new Counter[]{new Counter("ziemniaki"), new Counter("rzodkiewka"), new Counter("pomidory"), new Counter("marchewki")}; //tworzymy licznik dla kazdego istniejacego warzywa
        income = 0;
        costs = 0;

        for(int i = 0; i < garden.getNumberOfSlots(); i++)
            random_seed(garden, i); //sadzimy losowe warzywa na kazdym slocie

        for(int i = 0; i < days; i++)
        {
            turn(garden, i); //symualacja dnia rozniaca sie od implementacji taktyki
            garden.update(); //postarzanie warzyw
        }

        for(int i = 0; i < counters.length; i++)
            System.out.println("Zebrano " + counters[i].getCounter());

        System.out.printf("Laczne koszty: %.2f\n", costs);
        System.out.printf("Laczne zyski: %.2f\n", income);
        System.out.printf("Laczne zarobiono: %.2f\n\n", income - costs);
    }


    protected void random_seed(Garden garden, int i)
    {
            Random r = new Random();
            int rand = r.nextInt(counters.length);

            Vegetable tmp;

            switch (rand)
            {
                case 0:
                    tmp = new Potato();
                    break;
                case 1:
                    tmp = new Radish();
                    break;
                case 2:
                    tmp = new Tomato();
                    break;
                case 3:
                    tmp = new Carrot();
                    break;
                default:
                    System.out.println("Trying to seed nonexistent vegetable");
                    return;
            }

            costs += garden.seed(tmp, i);

    }

    protected void gather(Garden garden, int i)
    {
        String pack = new String("com.farmer.");
        Vegetable tmp = garden.gather(i);

        if(tmp.getClass().getName().equals(pack + "Potato"))
            counters[0].add();
        else if(tmp.getClass().getName().equals(pack + "Radish"))
            counters[1].add();
        else if(tmp.getClass().getName().equals(pack + "Tomato"))
            counters[2].add();
        else if(tmp.getClass().getName().equals(pack + "Carrot"))
            counters[3].add();
        else
        {
            System.out.println("Trying to gather nonexistent vegetable");
            return;
        }

        income += tmp.price_check();

        random_seed(garden, i);
    }

    protected abstract void turn(Garden garden, int turn_number);

}
