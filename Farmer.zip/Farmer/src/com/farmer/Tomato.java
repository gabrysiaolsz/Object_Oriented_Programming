package com.farmer;

public class Tomato extends Vegetable
{
    Tomato()
    {
        seed_price = 15.0f;
        age = 0;
    }

    @Override
    public float price_check() //cene pomidora okresla parabola
    {
        float price = -0.5f * age*(age - 20);

        if(price < 0)
            price = 0;

        return price;
    }
}
