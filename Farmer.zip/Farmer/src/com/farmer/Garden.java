package com.farmer;

import com.sun.org.apache.xpath.internal.objects.XNull;

public class Garden
{
    Vegetable[] vegies;

    Garden(int nos)
    {
        vegies = new Vegetable[nos];
    }

    public int getNumberOfSlots()
    {
        return vegies.length;
    }

    public void update()
    {
        for(Vegetable x: vegies)
            if(x != null)
                x.older();
    }

    public float seed(Vegetable veg, int slot)
    {
        if(vegies[slot] == null)
        {
            vegies[slot] = veg;
            return veg.getSeed_price();
        }
        else
        {
            System.out.println("Slot is already occupied!");
            return 0;
        }
    }

    public float evaluate_price(int slot)
    {
        if(vegies[slot] != null)
            return vegies[slot].price_check();

        return -1;
    }

    public Vegetable gather(int slot)
    {
        if(vegies[slot] != null)
        {
            Vegetable tmp = vegies[slot];
            vegies[slot] = null;

            return  tmp;
        }
        else
        {
            System.out.println("Can't gather empty slot!");
            return null;
        }

    }
}
