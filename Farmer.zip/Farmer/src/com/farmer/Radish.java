package com.farmer;

public class Radish extends Vegetable
{
    Radish()
    {
        seed_price = 10.0f;
        age = 0;
    }

    @Override
    public float price_check() //dwie f. liniowe, stala, i szybko malejaca, calosc ciągla
    {
        if(age < 10)
            return (float) age * 2;

        else if(age < 20)
            return (float) (18 + (age - 9) * 1.2);

        else if (age < 25)
            return 32.0f;

        else if(age < 29)
            return (float)32*25/age -(age -25)*(age-22);

        else
            return 0;

    }
}
