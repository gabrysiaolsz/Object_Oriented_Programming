public class Main {
    public static void main(String[] args) {
        //Obwód dla pierwszego prawa De Morgana
        Gate[] gates = new Gate[]{
                //~(p ^ q)
                new InputGate(),
                new InputGate(),
                new AND(),
                new NOT(),

                //~p v ~q
                new InputGate(),
                new InputGate(),
                new NOT(),
                new NOT(),
                new OR(),

                //Porównanie tych dwóch wartości
                new PARITY()
        };

        int[][] edges = new int[][]{
                {2},
                {2},
                {3},
                {9},

                {6},
                {7},
                {8},
                {8},
                {9},

                {}
        };

        Circuit circuit = new Circuit(gates, edges, 9);
        assert(circuit.evaluate(new boolean[]{true, true, true, true}));
        assert(circuit.evaluate(new boolean[]{true, false, true, false}));
        assert(circuit.evaluate(new boolean[]{false, true, false, true}));
        assert(circuit.evaluate(new boolean[]{false, false, false, false}));
        assert(!circuit.evaluate(new boolean[]{true, true, false, false}));
        assert(circuit.size() == 10);
        assert(circuit.inputLength() == 4);
        assert(circuit.depth() == 3);

        //Obwód dla drugiego prawa De Morgana
        gates = new Gate[]{
                //~(p v q)
                new InputGate(),
                new InputGate(),
                new AND(),
                new NOT(),

                //~p ^ ~q
                new InputGate(),
                new InputGate(),
                new NOT(),
                new NOT(),
                new OR(),

                //Porównanie tych dwóch wartości
                new PARITY()
        };

        //'edges' się nie zmienia, bo zależności między bramkami są takie same
        circuit = new Circuit(gates, edges, 9);
        assert(circuit.evaluate(new boolean[]{true, true, true, true}));
        assert(circuit.evaluate(new boolean[]{true, false, true, false}));
        assert(circuit.evaluate(new boolean[]{false, true, false, true}));
        assert(circuit.evaluate(new boolean[]{false, false, false, false}));
        assert(!circuit.evaluate(new boolean[]{true, true, false, false}));
        assert(circuit.size() == 10);
        assert(circuit.inputLength() == 4);
        assert(circuit.depth() == 3);

        //Dodawanie nowych bramek i krawędzi między nimi
        circuit.addGate(new InputGate());
        circuit.addEdge(10, 9); //Podłączenie nowo utworzonej bramki wejściowej(10) do bramki wyjściowej(9)
        assert(circuit.depth() == 1);
        assert(!circuit.evaluate(new boolean[]{true, true, true, true, true}));
        assert(circuit.evaluate(new boolean[]{true, true, true, true, false}));
    }
}
