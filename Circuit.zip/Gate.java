import java.util.ArrayList;

public abstract class Gate {
    ArrayList<Gate> inputGates = new ArrayList<>();

    boolean visited = false;
    int distanceFromOutput;

    boolean evaluated = false;
    boolean value;

    public abstract boolean evaluate();

    public void addInput(Gate gate) {
        inputGates.add(gate);
    }

    public void reset() {
        evaluated = false;
        visited = false;
    }

    public boolean isVisited() {
        return visited;
    }

    public void visit() {
        visited = true;
    }

    public int getDistance() {
        return distanceFromOutput;
    }

    public void setDistance(int distanceFromOutput) {
        this.distanceFromOutput = distanceFromOutput;
    }

    public ArrayList<Gate> getInputGates() {
        return inputGates;
    }
}
