public class NOT extends Gate {
    @Override
    public boolean evaluate() {
        if (evaluated) {
            return value;
        }

        value = !inputGates.get(0).evaluate();
        return value;
    }
}
