import java.util.ArrayList;
import java.util.Collections;

public class Circuit {
    ArrayList<Gate> gates = new ArrayList<>();
    ArrayList<InputGate> inputGates = new ArrayList<>();
    Gate outputGate;

    public Circuit(Gate[] gates, int[][] edges, int outputGate) {
        assert(gates.length == edges.length);

        Collections.addAll(this.gates, gates);
        this.outputGate = gates[outputGate];

        for (Gate gate : gates) {
            if (gate instanceof InputGate) {
                inputGates.add((InputGate)gate);
            }
        }

        for (int u = 0; u < edges.length; u++) {
            for (int v : edges[u]) {
                addEdge(u, v);
            }
        }
    }

    public void addGate(Gate gate) {
        gates.add(gate);
        if (gate instanceof InputGate) {
            inputGates.add((InputGate)gate);
        }
    }

    public void addEdge(int from, int to) {
        gates.get(to).addInput(gates.get(from));
    }

    private void reset() {
        for (Gate gate : gates) {
            gate.reset();
        }
    }

    public int inputLength() {
        return inputGates.size();
    }

    public int depth() {
        ArrayList<Gate> queue = new ArrayList<>();
        queue.add(outputGate);
        outputGate.visit();
        outputGate.setDistance(0);

        while (!queue.isEmpty()) {
            Gate current = queue.get(0);
            queue.remove(0);

            for (Gate next : current.getInputGates()) {
                if (next instanceof InputGate) {
                    reset();
                    return current.getDistance() + 1;
                }

                if (!next.isVisited()) {
                    next.visit();
                    next.setDistance(current.getDistance() + 1);
                    queue.add(next);
                }
            }
        }

        reset();
        return -1;
    }

    public int size() {
        return gates.size();
    }

    public boolean evaluate(boolean[] input) {
        assert(input.length == inputGates.size());

        for (int i = 0; i < input.length; i++) {
            inputGates.get(i).setValue(input[i]);
        }

        boolean b = outputGate.evaluate();
        reset();
        return b;
    }
}
