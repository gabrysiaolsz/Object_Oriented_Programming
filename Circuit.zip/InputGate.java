public class InputGate extends Gate {
    @Override
    public boolean evaluate() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }
}
