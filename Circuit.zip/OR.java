public class OR extends Gate {
    @Override
    public boolean evaluate() {
        if (evaluated) {
            return value;
        }
        evaluated = true;

        for (Gate g : inputGates) {
            if (g.evaluate()) {
                value = true;
                return value;
            }
        }

        value = false;
        return value;
    }
}
