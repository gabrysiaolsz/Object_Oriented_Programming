public class PARITY extends Gate {
    @Override
    public boolean evaluate() {
        if (evaluated) {
            return value;
        }
        evaluated = true;

        int count = 0;

        for (Gate g : inputGates) {
            if (g.evaluate()) {
                count++;
            }
        }

        value = count % 2 == 0;
        return value;
    }
}
