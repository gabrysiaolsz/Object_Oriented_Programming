public class MAJORITY extends Gate {
    @Override
    public boolean evaluate() {
        if (evaluated) {
            return value;
        }
        evaluated = true;

        int length = inputGates.size();
        int count = 0;

        for (Gate g : inputGates) {
            if (g.evaluate()) {
                count++;
            }
        }

        value = count > length / 2;
        return value;
    }
}
