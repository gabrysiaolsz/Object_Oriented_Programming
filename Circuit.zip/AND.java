public class AND extends Gate {
    @Override
    public boolean evaluate() {
        if (evaluated) {
            return value;
        }
        evaluated = true;

        for (Gate g : inputGates) {
            if (!g.evaluate()) {
                value = false;
                return value;
            }
        }

        value = true;
        return value;
    }
}
