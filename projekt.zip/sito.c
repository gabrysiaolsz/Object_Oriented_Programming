#include <stdio.h>

//zakres spośród którego wypisujemy liczby pierwsze
#ifndef N
#define N 1000
#endif


int main(void)
{
    //deklaracja tablicy liczb
    int liczby[N+1] = {0};
    int i, j;

    for(i=2; i*i<=N; i++)
    {
        if(!liczby[i])
        {
            for(j=i*i; j<=N; j+=i)
            {
                liczby[j]=1;
            }
        }
    }

    printf("Kolejne liczby pierwsze z przedziału [2, ..., %d] to:\n", N);

    for(i=2; i<=N; i++)
    {
        if(!liczby[i])
        {
            printf("%i ", i);
        }
    }

    return 0;
}